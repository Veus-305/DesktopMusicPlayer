@echo off
title Vvynas Vane - DEBUG (window stays open)
color 0E
cls

echo.
echo  ====================================================
echo   VVYNAS VANE - DEBUG MODE
echo   This window will STAY OPEN so you can read errors
echo  ====================================================
echo.

cd /d "%~dp0"

echo Python version:
python --version
echo.

echo Pip version:
python -m pip --version
echo.

echo Testing webview import:
python -c "import webview; print('webview OK - version:', webview.__version__)"
echo.

echo Testing mutagen import:
python -c "import mutagen; print('mutagen OK')"
echo.

echo App folder contents:
dir /b
echo.

echo Checking app\index.html:
if exist app\index.html (echo index.html FOUND) else (echo index.html MISSING - this is the problem)
echo.

echo.
echo  ====================================================
echo   Now launching app... read any errors below:
echo  ====================================================
echo.

python vvynas_vane.py
echo.
echo Exit code: %ERRORLEVEL%
echo.
echo  ====================================================
echo   Done. Read any errors above before pressing Enter.
echo  ====================================================
echo.
pause
