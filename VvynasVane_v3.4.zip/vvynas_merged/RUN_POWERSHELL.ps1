# VVYNAS VANE — PowerShell Launcher
# Right-click this file and select "Run with PowerShell"

$Host.UI.RawUI.WindowTitle = "Vvynas Vane Launcher"
$Host.UI.RawUI.BackgroundColor = "Black"
$Host.UI.RawUI.ForegroundColor = "Cyan"
Clear-Host

Write-Host ""
Write-Host "  ==========================================================" -ForegroundColor Cyan
Write-Host "    VVYNAS VANE - ALIEN AUDIO SYNTHESIS ENGINE v3.0" -ForegroundColor Cyan
Write-Host "    Windows Desktop Edition" -ForegroundColor Cyan
Write-Host "  ==========================================================" -ForegroundColor Cyan
Write-Host ""

# ── Find Python ────────────────────────────────────────────────────
$python = $null

foreach ($cmd in @("python", "python3", "py")) {
    try {
        $ver = & $cmd --version 2>&1
        if ($LASTEXITCODE -eq 0) {
            $python = $cmd
            Write-Host "  [OK] Found Python: $ver" -ForegroundColor Green
            break
        }
    } catch {}
}

if (-not $python) {
    Write-Host "  [!] Python not found on this computer." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "  Python is FREE and required to run Vvynas Vane." -ForegroundColor White
    Write-Host "  Download it from: https://www.python.org/downloads/" -ForegroundColor White
    Write-Host ""
    Write-Host "  IMPORTANT: During install, check the box that says:" -ForegroundColor Yellow
    Write-Host "  'Add Python to PATH'" -ForegroundColor Yellow
    Write-Host ""
    $open = Read-Host "  Open download page now? (y/n)"
    if ($open -eq "y" -or $open -eq "Y") {
        Start-Process "https://www.python.org/ftp/python/3.12.4/python-3.12.4-amd64.exe"
        Write-Host ""
        Write-Host "  After installing Python, close this window and run this script again." -ForegroundColor Cyan
    }
    Read-Host "  Press Enter to exit"
    exit 1
}

Write-Host ""

# ── Install packages ───────────────────────────────────────────────
$packages = @(
    @{name="pywebview"; import="webview"},
    @{name="mutagen";   import="mutagen"}
)

foreach ($pkg in $packages) {
    Write-Host "  [..] Checking $($pkg.name)..." -ForegroundColor Gray
    $check = & $python -c "import $($pkg.import)" 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Host "  [..] Installing $($pkg.name)..." -ForegroundColor Yellow
        & $python -m pip install $($pkg.name) --quiet --disable-pip-version-check
        if ($LASTEXITCODE -eq 0) {
            Write-Host "  [OK] $($pkg.name) installed." -ForegroundColor Green
        } else {
            Write-Host "  [ERROR] Failed to install $($pkg.name)." -ForegroundColor Red
            Write-Host "  Try running as Administrator." -ForegroundColor Yellow
            Read-Host "  Press Enter to exit"
            exit 1
        }
    } else {
        Write-Host "  [OK] $($pkg.name) ready." -ForegroundColor Green
    }
}

Write-Host ""
Write-Host "  [>>] Launching Vvynas Vane..." -ForegroundColor Cyan
Write-Host ""

# ── Launch app ─────────────────────────────────────────────────────
Set-Location $PSScriptRoot
& $python vvynas_vane.py

if ($LASTEXITCODE -ne 0) {
    Write-Host ""
    Write-Host "  [ERROR] App exited with error code $LASTEXITCODE" -ForegroundColor Red
    Read-Host "  Press Enter to exit"
}
