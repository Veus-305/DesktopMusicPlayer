@echo off
title Install Vvynas Vane Packages
color 0A
cls

echo.
echo  Installing Vvynas Vane required packages...
echo  This only needs to run ONCE.
echo.

:: Try python, then py
python --version >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    set PYTHON=python
    goto INSTALL
)
py --version >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    set PYTHON=py
    goto INSTALL
)

echo  ERROR: Python not found. Install Python first.
echo  https://www.python.org/downloads/
echo  (Check "Add to PATH" during install)
pause
exit /b

:INSTALL
echo  Python: %PYTHON%
echo.

echo  [1/3] Upgrading pip...
%PYTHON% -m pip install --upgrade pip

echo.
echo  [2/3] Installing pywebview...
%PYTHON% -m pip install pywebview==4.4.1

echo.
echo  [3/3] Installing mutagen...
%PYTHON% -m pip install mutagen

echo.
echo  ============================================
echo   All packages installed!
echo   You can now double-click RUN.bat to launch.
echo  ============================================
echo.
pause
