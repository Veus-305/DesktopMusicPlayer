@echo off
title Vvynas Vane
color 0A
cls

echo.
echo  ====================================================
echo   VVYNAS VANE v3.0 - ALIEN AUDIO SYNTHESIS ENGINE
echo  ====================================================
echo.

cd /d "%~dp0"

:: ─── STEP 1: Find Python ────────────────────────────────────────
echo [1/4] Looking for Python...

python --version
if %ERRORLEVEL% EQU 0 (
    set PY=python
    goto :found_python
)

py --version
if %ERRORLEVEL% EQU 0 (
    set PY=py
    goto :found_python
)

echo.
echo  ====================================================
echo   ERROR: Python is not installed.
echo  ====================================================
echo.
echo   1. Go to: https://www.python.org/downloads/
echo   2. Click the big yellow Download button
echo   3. Run the installer
echo   4. IMPORTANT: on the first screen tick the box:
echo      "Add Python to PATH"   (bottom of the screen)
echo   5. Click Install Now
echo   6. After it finishes - run RUN.bat again
echo.
pause
exit /b 1

:found_python
echo [OK] Python found.
echo.

:: ─── STEP 2: Install pywebview ──────────────────────────────────
echo [2/4] Checking pywebview...
%PY% -c "import webview" 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo Installing pywebview - please wait...
    %PY% -m pip install pywebview==4.4.1
    if %ERRORLEVEL% NEQ 0 (
        echo.
        echo  ====================================================
        echo   ERROR: pip install failed.
        echo  ====================================================
        echo.
        echo   Try these fixes:
        echo   1. Right-click RUN.bat and choose "Run as administrator"
        echo   2. Check your internet connection
        echo   3. Or open cmd and type:
        echo      pip install pywebview==4.4.1
        echo.
        pause
        exit /b 1
    )
)
echo [OK] pywebview ready.
echo.

:: ─── STEP 3: Install mutagen ────────────────────────────────────
echo [3/4] Checking mutagen...
%PY% -c "import mutagen" 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo Installing mutagen...
    %PY% -m pip install mutagen
)
echo [OK] mutagen ready.
echo.

:: ─── STEP 4: Launch app ─────────────────────────────────────────
echo [4/4] Starting Vvynas Vane...
echo.
echo  If a window does not open within 10 seconds,
echo  read the error message below.
echo.

%PY% vvynas_vane.py
set ERR=%ERRORLEVEL%

if %ERR% NEQ 0 (
    echo.
    echo  ====================================================
    echo   APP CRASHED - Exit code: %ERR%
    echo  ====================================================
    echo.
    echo   Most common causes:
    echo.
    echo   1. Missing WebView2 runtime
    echo      Fix: Download and run this file:
    echo      https://go.microsoft.com/fwlink/p/?LinkId=2124703
    echo.
    echo   2. Missing Visual C++ Redistributable
    echo      Fix: Download from:
    echo      https://aka.ms/vs/17/release/vc_redist.x64.exe
    echo.
    echo   3. Antivirus blocking the app
    echo      Fix: Temporarily disable antivirus, try again
    echo.
    echo   Check debug_log.txt in this folder for details.
    echo.
)

pause
