╔══════════════════════════════════════════════════════════════╗
║   VVYNAS VANE — ALIEN AUDIO SYNTHESIS ENGINE v3.0           ║
║   Windows Desktop Edition — Setup Guide                      ║
╚══════════════════════════════════════════════════════════════╝

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  QUICK START (2 steps)
  
  Step 1:  Install Python (free, 2 minutes, one-time)
  Step 2:  Double-click  RUN.bat  to launch the app

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


STEP 1 — INSTALL PYTHON
━━━━━━━━━━━━━━━━━━━━━━━

  1. Open this link in your browser:
     https://www.python.org/ftp/python/3.12.4/python-3.12.4-amd64.exe

  2. Run the downloaded file (python-3.12.4-amd64.exe)

  3. On the FIRST screen of the installer:
     ✔  Check the box: "Add Python to PATH"    ← IMPORTANT!
        (it is at the bottom, unchecked by default)

  4. Click "Install Now"

  5. Wait for it to finish (~1-2 minutes)

  6. Click "Close"

  Python is now installed. You will never need to do this again.


STEP 2 — RUN THE APP
━━━━━━━━━━━━━━━━━━━━

  Option A (easiest):
    Double-click  RUN.bat
    
    On first run, it will automatically install 2 small packages
    (pywebview and mutagen). This takes about 30 seconds.
    Then Vvynas Vane will open automatically.

  Option B (if RUN.bat is blocked by Windows):
    Right-click  RUN_POWERSHELL.ps1
    → Select "Run with PowerShell"
    → If asked about execution policy, type "Y" and press Enter

  Option C (manual, using Command Prompt):
    1. Open Command Prompt (search "cmd" in Start menu)
    2. Type:  cd  then drag the vvynas_win folder into the window
    3. Press Enter
    4. Type:  pip install pywebview mutagen
    5. Press Enter, wait for it to finish
    6. Type:  python vvynas_vane.py
    7. Press Enter


EVERY TIME AFTER THAT
━━━━━━━━━━━━━━━━━━━━━

  Just double-click  RUN.bat
  The app opens in about 3-5 seconds.
  No internet needed after the first setup.


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

HOW TO USE THE APP
━━━━━━━━━━━━━━━━━━

  OPEN YOUR MUSIC
  ─────────────────
  Click "◈ OPEN FOLDER" button at the top.
  Select any folder on your computer with music files.
  The app scans it and shows all tracks (MP3, FLAC, WAV, M4A, etc).
  Album art and artist info loads automatically in the background.

  PLAY MUSIC
  ───────────
  • Click any track to play it immediately
  • Use the player bar at the bottom to control playback
  • Click the progress bar to seek within a track
  • Right-click any track for more options

  MULTI-SELECT (add many tracks at once)
  ──────────────────────────────────────
  • Hold Ctrl and click multiple tracks to select them
  • A bar appears showing how many are selected
  • Click "＋ ADD TO PLAYLIST" to add them all at once

  ANIMATED BACKGROUND THEMES
  ────────────────────────────
  Click the palette icon (🎨) in the bottom-right of the player.
  Choose from 11 animated themes:
    WAVES, VOLCANO, SUNSET, WINDMILL, WATERFALL,
    UNDERSEA, SMOKE, PIANO, THINKING, AURORA
  Use the sliders to control how bright and blurred the background is.

  EQUALIZER
  ──────────
  Click the EQ icon in the bottom-right.
  Drag the 5 band sliders, or choose a preset:
  FLAT, BASS+, TREBLE+, ALIEN SYNC, CYBER WAVE, DEEP SPACE

  VIDEO / M4A FILES
  ──────────────────
  Click the "VIDEO" tab to see all video and M4A files
  in your scanned folder. Click any file to play it.

  PLAYLISTS
  ──────────
  Click "＋ PLAYLIST" to create a playlist.
  Right-click any track → "Add to Playlist".
  Playlists are saved automatically — they appear next time you open the app.

  SETTINGS
  ─────────
  Click "⬡ SETTINGS" to change font, crossfade, and more.


KEYBOARD SHORTCUTS
━━━━━━━━━━━━━━━━━━
  Space         Play / Pause
  Ctrl + →      Next track
  Ctrl + ←      Previous track
  Ctrl + ↑      Volume up
  Ctrl + ↓      Volume down
  Ctrl + S      Toggle shuffle
  Ctrl + E      Open equalizer
  Ctrl + T      Open theme picker
  Ctrl + F      Focus search box
  Escape        Close menus / exit selection mode


WHERE YOUR DATA IS SAVED
━━━━━━━━━━━━━━━━━━━━━━━━
  Playlists and settings are saved here:
  C:\Users\YourName\.vvynas_vane\

  Files in that folder:
  • settings.json        — all your preferences
  • PlaylistName.json    — one file per playlist


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

TROUBLESHOOTING
━━━━━━━━━━━━━━━

  PROBLEM: "python is not recognized"
  FIX: You forgot to check "Add Python to PATH" during install.
       Uninstall Python from Control Panel, reinstall, and this
       time check that box on the first screen.

  PROBLEM: Windows says "Windows protected your PC" when running RUN.bat
  FIX: Click "More info" → "Run anyway". This is normal for
       unsigned scripts downloaded from the internet.

  PROBLEM: App opens but no sound plays
  FIX: The audio file format might not be supported by your system.
       Make sure you have proper codecs installed. K-Lite Codec Pack
       (free) fixes most audio issues on Windows.

  PROBLEM: App opens a blank white window
  FIX: Your Windows might be missing WebView2. Download it free:
       https://developer.microsoft.com/en-us/microsoft-edge/webview2/
       Click "Download" → "Evergreen Bootstrapper"

  PROBLEM: "ModuleNotFoundError: No module named 'webview'"
  FIX: Run this in Command Prompt:
       pip install pywebview
       Then try launching the app again.

  PROBLEM: Tracks show "UNKNOWN ARTIST" or no album art
  FIX: Normal — metadata loads in the background. Wait 15-30 seconds
       after opening a folder, especially for large music libraries.

  PROBLEM: App is slow on a large music folder
  FIX: The app only loads metadata for the first 200 tracks on startup.
       The rest loads gradually. Start playback while it scans.


FILE FORMATS SUPPORTED
━━━━━━━━━━━━━━━━━━━━━━
  Audio: MP3, FLAC, WAV, AAC, OGG, M4A, WMA, OPUS, AIFF, APE, WV
  Video: MP4, MKV, AVI, MOV, WEBM, M4V, FLV, WMV, 3GP, TS


PROJECT FILES
━━━━━━━━━━━━━
  vvynas_win/
  ├── RUN.bat              ← Double-click to launch (Windows)
  ├── RUN_POWERSHELL.ps1   ← Alternative launcher (PowerShell)
  ├── vvynas_vane.py       ← Main application code
  ├── requirements.txt     ← Package list for manual install
  ├── README.txt           ← This file
  └── app/
      └── index.html       ← Full UI (HTML + CSS + JS)


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Vvynas Vane Desktop v3.0 — Windows Edition
  Built with Python + pywebview
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

IF THE APP CLOSES IMMEDIATELY — DEBUG STEPS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Step 1: Double-click INSTALL_PACKAGES.bat
          This installs the exact right versions of everything.
          Wait for it to finish and say "All packages installed".

  Step 2: Double-click DEBUG.bat (not RUN.bat)
          This keeps the window open so you can see the error.
          Read the error message and use the fixes below.

  Common errors and fixes:

  Error: "No module named webview"
  Fix: Run INSTALL_PACKAGES.bat then try again.

  Error: "WebView2 is not available" or blank white window
  Fix: Download WebView2 runtime from:
       https://developer.microsoft.com/microsoft-edge/webview2/
       Click Download → Evergreen Bootstrapper → run it

  Error: "Access denied" or "Permission error"
  Fix: Right-click RUN.bat → Run as administrator

  Error: "DLL load failed"
  Fix: Install Visual C++ Redistributable:
       https://aka.ms/vs/17/release/vc_redist.x64.exe

  Still stuck? Open debug_log.txt (created in the vvynas_win folder)
  and share its contents for help.

