"""
VVYNAS VANE v3.1 - Windows Desktop (FIXED)
Fixes:
  - pywebview JS API injection (window.pywebview.api vs window.pyapi)
  - Local file serving via HTTP so audio/video actually plays
  - Folder dialog error handling
  - Path normalisation on Windows (backslash → forward slash)
"""
import sys, os, json, traceback, threading, mimetypes
from pathlib import Path
from http.server import HTTPServer, BaseHTTPRequestHandler

BASE = Path(__file__).parent
LOG  = BASE / "debug_log.txt"
DATA = Path.home() / ".vvynas_vane"

# ── Logging ────────────────────────────────────────────────────────
def log(msg):
    print(msg, flush=True)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(msg + "\n")
    except Exception:
        pass

try:
    LOG.write_text("", encoding="utf-8")
except Exception:
    pass

log("=" * 55)
log("VVYNAS VANE v3.1 - Starting up (FIXED BUILD)")
log(f"Python: {sys.version}")
log(f"OS: {sys.platform}")
log(f"Script dir: {BASE}")
log("=" * 55)

# ── Install missing packages ───────────────────────────────────────
def install(pkg, import_as=None):
    import_as = import_as or pkg
    try:
        __import__(import_as)
        log(f"[OK] {pkg} already installed")
        return True
    except ImportError:
        log(f"[..] Installing {pkg}...")
        import subprocess
        r = subprocess.run(
            [sys.executable, "-m", "pip", "install", pkg],
            capture_output=True, text=True
        )
        log(r.stdout)
        if r.stderr:
            log(r.stderr)
        if r.returncode == 0:
            log(f"[OK] {pkg} installed")
            return True
        log(f"[FAIL] {pkg} install failed")
        return False

log("\nChecking packages...")
wv_ok  = install("pywebview==4.4.1", "webview")
mut_ok = install("mutagen", "mutagen")

if not wv_ok:
    msg = (
        "\n" + "="*55 + "\n"
        "FATAL: pywebview could not be installed.\n\n"
        "Fix: Open Command Prompt and run:\n"
        "  pip install pywebview==4.4.1\n\n"
        "Then run RUN.bat again.\n"
        + "="*55
    )
    log(msg)
    input(msg + "\n\nPress Enter to close...")
    sys.exit(1)

log("\nImporting webview...")
try:
    import webview
    ver = getattr(webview, '__version__', getattr(webview, 'version', 'unknown'))
    log(f"[OK] webview imported - version: {ver}")
except Exception as e:
    msg = (
        f"\nFATAL: Cannot import webview\n"
        f"Error: {e}\n\n"
        f"This usually means WebView2 runtime is missing.\n"
        f"Download it from:\n"
        f"https://go.microsoft.com/fwlink/p/?LinkId=2124703\n"
        f"(Run the downloaded file, then try again)"
    )
    log(msg)
    log(traceback.format_exc())
    input(msg + "\n\nPress Enter to close...")
    sys.exit(1)

try:
    DATA.mkdir(parents=True, exist_ok=True)
    log(f"[OK] Data dir: {DATA}")
except Exception as e:
    log(f"[WARN] Could not create data dir: {e}")

AUDIO = {'.mp3','.flac','.wav','.aac','.ogg','.m4a',
         '.wma','.opus','.aiff','.ape','.wv'}
VIDEO = {'.mp4','.mkv','.avi','.mov','.webm',
         '.m4v','.flv','.wmv','.3gp','.ts'}

# ── Local HTTP file server ────────────────────────────────────────
# WebView2 blocks file:// media in many configs.
# A tiny localhost server fixes audio/video playback + seeking.

_file_server      = None
_file_server_port = None

class _FileHandler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass  # silence default access log

    def do_GET(self):
        from urllib.parse import unquote, urlparse, parse_qs
        qs  = parse_qs(urlparse(self.path).query)
        raw = qs.get('f', [None])[0]
        if not raw:
            self.send_error(400, "Missing ?f= parameter")
            return
        fp = Path(unquote(raw))
        if not fp.exists() or not fp.is_file():
            self.send_error(404, f"Not found: {fp}")
            return

        size = fp.stat().st_size
        rng  = self.headers.get('Range', '')
        mime = mimetypes.guess_type(str(fp))[0] or 'application/octet-stream'

        try:
            if rng and rng.startswith('bytes='):
                lo_s, hi_s = rng[6:].split('-')
                lo = int(lo_s)
                hi = int(hi_s) if hi_s else size - 1
                hi = min(hi, size - 1)
                length = hi - lo + 1
                self.send_response(206)
                self.send_header('Content-Type', mime)
                self.send_header('Content-Range', f'bytes {lo}-{hi}/{size}')
                self.send_header('Content-Length', str(length))
                self.send_header('Accept-Ranges', 'bytes')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                with open(fp, 'rb') as fh:
                    fh.seek(lo)
                    remaining = length
                    while remaining > 0:
                        chunk = fh.read(min(65536, remaining))
                        if not chunk:
                            break
                        self.wfile.write(chunk)
                        remaining -= len(chunk)
            else:
                self.send_response(200)
                self.send_header('Content-Type', mime)
                self.send_header('Content-Length', str(size))
                self.send_header('Accept-Ranges', 'bytes')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                with open(fp, 'rb') as fh:
                    while True:
                        chunk = fh.read(65536)
                        if not chunk:
                            break
                        self.wfile.write(chunk)
        except (BrokenPipeError, ConnectionResetError):
            pass  # client closed early — normal for seek
        except Exception as e:
            log(f"[FileServer] Error serving {fp}: {e}")


def _start_file_server():
    global _file_server, _file_server_port
    _file_server = HTTPServer(('127.0.0.1', 0), _FileHandler)
    _file_server_port = _file_server.server_address[1]
    log(f"[OK] File server started on port {_file_server_port}")
    t = threading.Thread(target=_file_server.serve_forever, daemon=True)
    t.start()


def media_url(path: str) -> str:
    """Convert a local Windows file path to a localhost URL."""
    from urllib.parse import quote
    norm = str(path).replace('\\', '/')
    return f"http://127.0.0.1:{_file_server_port}/?f={quote(norm, safe='/:')}"


_start_file_server()


# ── API class exposed to JavaScript ──────────────────────────────
class API:

    def get_media_base(self):
        """JS calls this once on init to build media URLs."""
        return f"http://127.0.0.1:{_file_server_port}/"

    def scan_folder(self, path):
        log(f"scan_folder: {path}")
        out = []
        try:
            for root, dirs, files in os.walk(str(path)):
                dirs[:] = [d for d in dirs if not d.startswith('.')]
                if str(root).replace(str(path), '').count(os.sep) > 6:
                    continue
                for f in files:
                    ext = Path(f).suffix.lower()
                    if ext in AUDIO or ext in VIDEO:
                        fp = os.path.join(root, f)
                        try:
                            st = os.stat(fp)
                            out.append({
                                'path':    fp,
                                'name':    Path(f).stem,
                                'ext':     ext,
                                'size':    st.st_size,
                                'isVideo': ext in VIDEO,
                                'mtime':   st.st_mtime * 1000,
                                'url':     media_url(fp),
                            })
                        except Exception:
                            pass
        except Exception as e:
            log(f"scan error: {e}")
        log(f"Found {len(out)} files")
        return out

    def open_folder_dialog(self):
        log("open_folder_dialog called")
        try:
            wins = webview.windows
            if not wins:
                log("[WARN] No window found for dialog")
                return None
            r = wins[0].create_file_dialog(webview.FOLDER_DIALOG)
            if r and len(r) > 0:
                log(f"Selected: {r[0]}")
                return r[0]
            log("Dialog cancelled")
            return None
        except Exception as e:
            log(f"dialog error: {e}\n{traceback.format_exc()}")
            return None

    def get_default_music_dir(self):
        candidates = [
            Path.home() / "Music",
            Path.home() / "music",
            Path.home() / "Desktop",
            Path.home(),
        ]
        for p in candidates:
            if p.exists():
                log(f"default dir: {p}")
                return str(p)
        return str(Path.home())

    def get_metadata(self, path):
        if not mut_ok:
            return None
        try:
            from mutagen import File as MF
            import base64
            a = MF(path, easy=True)
            if not a:
                return None
            meta = {'title': None, 'artist': None, 'album': None,
                    'year': None, 'duration': 0, 'cover': None}
            if hasattr(a, 'info') and hasattr(a.info, 'length'):
                meta['duration'] = a.info.length
            if a.tags:
                def g(k):
                    v = a.tags.get(k)
                    return str(v[0] if isinstance(v, list) else v) if v else None
                meta['title']  = g('title')
                meta['artist'] = g('artist')
                meta['album']  = g('album')
                meta['year']   = g('date')
            try:
                raw = MF(path)
                if raw and raw.tags:
                    for tag in raw.tags.values():
                        if hasattr(tag, 'data') and hasattr(tag, 'mime'):
                            meta['cover'] = f"data:{tag.mime};base64,{base64.b64encode(tag.data).decode()}"
                            break
                        if 'MP4Cover' in str(type(tag)):
                            fmt = 'image/jpeg' if getattr(tag, 'imageformat', 13) == 13 else 'image/png'
                            meta['cover'] = f"data:{fmt};base64,{base64.b64encode(bytes(tag)).decode()}"
                            break
            except Exception:
                pass
            return meta
        except Exception as e:
            log(f"metadata error {path}: {e}")
            return None

    def save_playlist(self, name, songs):
        try:
            safe = "".join(c for c in name if c.isalnum() or c in ' _-').strip()
            with open(DATA / f"{safe}.json", 'w', encoding='utf-8') as f:
                json.dump({'name': name, 'songs': songs}, f, indent=2)
            return True
        except Exception as e:
            log(f"save_playlist error: {e}")
            return False

    def load_playlists(self):
        out = []
        try:
            for p in DATA.glob("*.json"):
                if p.name == 'settings.json':
                    continue
                try:
                    with open(p, 'r', encoding='utf-8') as f:
                        out.append(json.load(f))
                except Exception:
                    pass
        except Exception as e:
            log(f"load_playlists error: {e}")
        return out

    def delete_playlist(self, name):
        try:
            safe = "".join(c for c in name if c.isalnum() or c in ' _-').strip()
            p = DATA / f"{safe}.json"
            if p.exists():
                p.unlink()
            return True
        except Exception as e:
            log(f"delete_playlist error: {e}")
            return False

    def load_settings(self):
        try:
            p = DATA / "settings.json"
            if p.exists():
                with open(p, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except Exception as e:
            log(f"load_settings error: {e}")
        return {}

    def save_settings(self, settings):
        try:
            with open(DATA / "settings.json", 'w', encoding='utf-8') as f:
                json.dump(settings, f, indent=2)
            return True
        except Exception as e:
            log(f"save_settings error: {e}")
            return False


# ── Main ──────────────────────────────────────────────────────────
def main():
    html = BASE / "app" / "index.html"

    if not html.exists():
        msg = (
            f"\nFATAL: index.html not found!\n"
            f"Expected: {html}\n\n"
            f"Make sure you extracted the full ZIP.\n"
            f"The 'app' folder must be inside 'vvynas_win'."
        )
        log(msg)
        input(msg + "\n\nPress Enter to close...")
        sys.exit(1)

    log(f"[OK] index.html found: {html}")
    log("Creating window...")

    try:
        win = webview.create_window(
            title            = 'Vvynas Vane',
            url              = html.as_uri(),
            js_api           = API(),
            width            = 1280,
            height           = 820,
            min_size         = (900, 620),
            background_color = '#020408',
        )
        log("[OK] Window created - starting event loop")
        webview.start(debug=False)
        log("App closed normally.")

    except Exception as e:
        msg = (
            f"\nFATAL: webview.start() crashed\n"
            f"Error: {e}\n\n"
            f"Most likely cause: WebView2 runtime is missing.\n"
            f"Download: https://go.microsoft.com/fwlink/p/?LinkId=2124703\n"
            f"Run the downloaded MicrosoftEdgeWebview2Setup.exe\n"
            f"Then try RUN.bat again."
        )
        log(msg)
        log(traceback.format_exc())
        input(msg + "\n\nPress Enter to close...")
        sys.exit(1)


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        msg = f"\nUnhandled crash: {e}\n{traceback.format_exc()}"
        log(msg)
        input(msg + "\n\nPress Enter to close...")
        sys.exit(1)
